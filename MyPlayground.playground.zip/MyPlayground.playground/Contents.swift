//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//add names of friends in below in quotes seprated by comma
var names = ["Just","add","comma","seprated","names"]
var dict = [Int:Int]()
var dictNames = [String:String]()
let count = names.count

for i in 0..<count{
    var random = 0
    repeat{
      random  = Int(arc4random_uniform(UInt32(count)))
    } while(dict.values.contains(random) || i == random )
    dict[i] = random
}
for (key,value) in dict {
    var strName = names[key]
    var strName2 = names[value]
    dictNames[strName] = strName2
    print (strName,strName2)
}
dictNames
